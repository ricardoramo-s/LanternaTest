package org.example;

import java.util.ArrayList;
import java.util.List;

public class Map {
    int height;
    int width;
    List<List<Image>> map = new ArrayList<>();

    public Map() {}
}
