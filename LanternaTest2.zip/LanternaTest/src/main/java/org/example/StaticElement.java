package org.example;

public class StaticElement {
    int x;
    int y;
    int id;
    Image sprite;

    public StaticElement (int x, int y, int id, Image image) {
        this.x = x;
        this.y = y;
        this.id = id;
        this.sprite = image;
    }
}
